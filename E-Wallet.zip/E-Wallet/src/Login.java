
import java.awt.*;
import javax.swing.*;

import com.mysql.jdbc.Statement;

import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.*;

public class Login implements ActionListener,MouseListener,FocusListener  
{
	JFrame jf;
	JPanel jp1,jp2,jp3,jp4,jp5;
	JLabel logo,jl1,uidicon,passwordicon,error,jl2,pass;
	JTextField uid;
	JPasswordField password;
	JButton login,signup,close;
	JTextArea jta1;
	int balance;
	Connection con;
	java.sql.Statement stmt;
	int id;
	
	
	Login()
	{
		jf=new JFrame();
		jf.setLayout(null);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg26.jpg")));
		
		jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setContentAreaFilled(false);
		close.setBounds(5, 5, 25, 25);
		
		jf.add(jl2=new JLabel("New User?"));
		jl2.setBorder(null);
		jl2.setOpaque(false);
		jl2.setBounds(1160, 10, 100, 40);
		jl2.setFont(new Font("Cooper",Font.BOLD,17));
		jl2.setForeground(Color.white);

		jf.add(signup=new JButton("Sign Up"));
		signup.setBorder(BorderFactory.createLineBorder(Color.white));
		signup.setContentAreaFilled(false);
		signup.setBounds(1256, 10, 100, 40);
		signup.setFont(new Font("Cooper",Font.PLAIN,20));
		signup.setForeground(Color.white);
		signup.addActionListener(this);
		
		jf.add(jp1=new JPanel());
		jp1.setLayout(null);
		jp1.setBounds(456, 100,456 ,500);
		jp1.setBackground(new Color(0,0,0,70));
		jp1.setOpaque(false);
				jp1.add(logo=new JLabel());
					logo.setIcon(new ImageIcon("C:\\Users\\Abhinay\\Desktop\\javaprograms\\Swing\\pic\\xlogo.png"));
					logo.setBounds(115, 5, 250, 150);
				jp1.add(jl1=new JLabel());
					jl1.setBounds(110, 165, 240, 60);
					jl1.setText("Admin Login");
					jl1.setFont(new Font("Comic Sans MS",Font.BOLD,40));
					jl1.setForeground(new Color(74,10,88,255));
				jp1.add(jp2=new JPanel());
					jp2.setBounds(0, 290, 456, 40);
					jp2.setBackground(new Color(0,0,0,40));
					jp2.setLayout(null);
						jp2.add(uidicon=new JLabel(new ImageIcon("img\\uidicon.png")));
						jp2.add(jp4=new JPanel());
						jp2.add(uid=new JTextField("Username"));
						uid.addFocusListener(this);
						uid.setBackground(Color.DARK_GRAY);
						uid.setBorder(null);
						uid.setForeground(Color.white);
						uid.setFont(new Font("Cooper",Font.PLAIN,20));
						uidicon.setBounds(5, 5, 30, 30);
						jp4.setBounds(40, 5, 1, 30);
						uid.setBounds(45, 5, 406, 30);
						
						
				jp1.add(jp3=new JPanel());
					jp3.setBounds(0, 350, 456, 40);
					jp3.setBackground(new Color(0,0,0,40));
					jp3.setLayout(null);
						jp3.add(passwordicon=new JLabel(new ImageIcon("img\\passwordicon.png")));
						jp3.add(jp5=new JPanel());
						jp3.add(password=new JPasswordField());
						password.addFocusListener(this);
						password.setFont(new Font("Cooper",Font.PLAIN,15));
						password.setBackground(Color.DARK_GRAY);
						password.setBorder(null);
						password.setForeground(Color.WHITE);
						passwordicon.setBounds(5, 5, 30, 30);
						jp5.setBounds(40, 5, 1, 30);
						password.setBounds(45, 5, 406, 30);
						password.add(pass=new JLabel("Password"));
							pass.setBounds(0,0,406,30);
							pass.setBorder(BorderFactory.createEmptyBorder());
							pass.setOpaque(false);
							pass.setFont(new Font("Cooper",Font.PLAIN,20));
							pass.setForeground(Color.white);
					
				jp1.add(login=new JButton("<html><font color=white size=6>LOGIN</font></html>"));
					login.setBounds(0, 410, 456, 40);
					login.setBackground(new Color(78,27,133,255));
					login.setBorder(BorderFactory.createRaisedBevelBorder());
					
				jp1.add(passwordicon=new JLabel());
				jp1.add(error=new JLabel());
				
				
		close.addMouseListener(this);		
		signup.addMouseListener(this);	
		close.addActionListener(this);
		login.addActionListener(this);
		signup.addActionListener(this);
		
		jf.setUndecorated(true);
		jf.setExtendedState(jf.MAXIMIZED_BOTH);
		jf.setVisible(true);
		jf.setResizable(false);
		
		try {
		Class.forName("com.mysql.jdbc.Driver");
		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet","root","abhi");
		stmt=con.createStatement();
		}
		catch(Exception e) {}
		
	}
	
	public static void main(String[] args) 
	{
		new Login();
	}

	
	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==login)
		{
			
			
			String p1=password.getText();
			String p2;
			
			try {
				ResultSet rs=stmt.executeQuery("select * from login where username='"+uid.getText()+"'");
				
				if(rs.next())
				{
					
					p2=rs.getString("password");
					id=rs.getInt("id");
					String iid=Integer.toString(id);
					ResultSet rs1=stmt.executeQuery("select * from bank where acc_no='"+iid+"'");
					if(rs1.next())
					{
						balance=rs1.getInt("balance");
					}
					if(p1.equals(p2))
					{
						new Wallet_Home(id,balance,uid.getText());
					}
					else
						JOptionPane.showMessageDialog(jf,"INVALID PASSWORD!!");
				
					
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		if(ae.getSource()==close)
		{
			new Fpage();
		}
		if(ae.getSource()==signup)
		{
			new Option();
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) 
	{
		
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) 
	{
		if(arg0.getComponent()==close)
		{
		close.setContentAreaFilled(true);
		close.setBackground(Color.red);
		}
		if(arg0.getComponent()==signup)
		{
		signup.setContentAreaFilled(true);
		signup.setBackground(new Color(78,27,133,255));
		}
	}

	@Override
	public void mouseExited(MouseEvent arg0) 
	{
		close.setContentAreaFilled(false);
		signup.setContentAreaFilled(false);
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusGained(FocusEvent e) 
	{
		if(e.getSource() == uid)
		{
			uid.setText("");
		}
		else if(e.getSource() == password)
		{
			pass.setVisible(false);
		}
		
	}

	@Override
	public void focusLost(FocusEvent e) 
	{
		if(e.getSource() == uid)
		{
			if(uid.getText().equals(""))
			{
				uid.setText("Username");
			}
		}
		else if(e.getSource() == password)
		{
			if(password.getText().equals(""))
			{
				pass.setVisible(true);
			}
		}
		
	}
}
