import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Option implements ActionListener,MouseListener
{
	JFrame jf;
	JPanel jp1;
	JButton close,submit;
		
	
	JRadioButton rb1,rb2,rb3;
	ButtonGroup bg;
	
	Option()
	{
		jf=new JFrame();
		jf.setLayout(null);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg37.jpg")));
		jf.setSize(500, 270);
		
		jf.add(jp1=new JPanel());
		jp1.setBounds(100,0,300 ,250);
		jp1.setLayout(null);
		jp1.setBackground(new Color(0,0,0,100));
		jp1.setBorder(BorderFactory.createTitledBorder("<html><body color='orange'><font size=7>Who Are You?</font></body></html>"));

		jp1.add(rb1=new JRadioButton("STUDENT"));
		rb1.setBounds(10, 60, 280, 25);
		rb1.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		rb1.setBackground(Color.DARK_GRAY);
		rb1.setForeground(Color.WHITE);
		
		jp1.add(rb2=new JRadioButton("FACULTY"));
		rb2.setBounds(10, 100, 280, 25);
		rb2.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		rb2.setBackground(Color.DARK_GRAY);
		rb2.setForeground(Color.WHITE);
		
		jp1.add(rb3=new JRadioButton("VENDOR"));
		rb3.setBounds(10, 140, 280, 25);
		rb3.setFont(new Font("Comic Sans MS",Font.BOLD,20));
		rb3.setBackground(Color.DARK_GRAY);
		rb3.setForeground(Color.WHITE);
		
		jp1.add(submit=new JButton("Submit"));
		submit.setBounds(50, 180, 200, 50);
		submit.setFont(new Font("Cooper",Font.BOLD,40));
		submit.setForeground(Color.white);
		submit.setBackground(new Color(78,27,133,255));
		submit.setBorder(BorderFactory.createCompoundBorder());
		
		bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		bg.add(rb3);
		
		jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setBounds(5, 5, 25, 25);
		close.setBackground(Color.red);
		close.setContentAreaFilled(false);
		
		jf.setUndecorated(true);
		jf.setVisible(true);
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		
		close.addActionListener(this);
		submit.addActionListener(this);
		close.addMouseListener(this);
		
		
		
	}
	
	public static void main(String[] args) 
	{
		new Option();
	}


	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==close)
		{
			jf.setVisible(false);
		}
		if(ae.getSource()==submit)
		{
			if(bg.getSelection()==rb1.getModel())
			{
				jf.dispose();
				new Signup_Student();
			}
			if(bg.getSelection()==rb2.getModel())
			{
				jf.dispose();
				new Signup_Faculty();
			}
			if(bg.getSelection()==rb3.getModel())
			{
				jf.dispose();
				new Signup_Vendor();
			}
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getComponent()==close)
		{
		close.setContentAreaFilled(true);
		close.setBackground(Color.red);
		}

		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		close.setContentAreaFilled(false);
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}	