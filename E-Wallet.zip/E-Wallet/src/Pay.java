import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Pay implements ActionListener,MouseListener
{
	JFrame jf;
	JPanel jp1;
	JButton close,pay;
	JTextField reciever,amount,detail;
	JLabel rl,al,dl;
	Connection con;
	Statement stmt;
	int acc,tid;
	String d;
	
	Pay(int a)
	{
		this();
		acc=a;
	}
	Pay()
	{
		jf=new JFrame();
		jf.setLayout(null);
		jf.setSize(500, 315);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg37.jpg")));
		
		
		jf.add(jp1=new JPanel());
		jp1.setBounds(100,0,300 ,315);
		jp1.setLayout(null);
		jp1.setBackground(new Color(0,0,0,100));
		
		jp1.add(rl=new JLabel("Receiver's Account Number:"));
		rl.setBounds(10, 10, 280, 50);
		rl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		rl.setHorizontalTextPosition(SwingConstants.LEFT);
		rl.setForeground(Color.ORANGE);
												
		jp1.add(reciever=new JTextField());
		reciever.setBounds(10, 50, 280, 25);
		reciever.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		reciever.setBorder(null);
		
		
		jp1.add(al=new JLabel("Amount:"));
		al.setBounds(10, 80, 280, 50);
		al.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		al.setHorizontalTextPosition(SwingConstants.LEFT);
		al.setForeground(Color.orange);
		
		jp1.add(amount=new JTextField());
		amount.setBounds(10, 120, 280, 25);
		amount.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		amount.setBorder(null);
		
		jp1.add(dl=new JLabel("Detail:"));
		dl.setBounds(10, 150, 280, 50);
		dl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		dl.setHorizontalTextPosition(SwingConstants.LEFT);
		dl.setForeground(Color.ORANGE);
		
		
		jp1.add(detail=new JTextField());
		detail.setBounds(10, 190, 280, 25);
		detail.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		detail.setBorder(null);
		
		
		jp1.add(pay=new JButton("PAY"));
		pay.setBounds(50, 240, 200, 50);
		pay.setFont(new Font("Cooper",Font.BOLD,40));
		pay.setForeground(Color.white);
		pay.setBackground(new Color(78,27,133,255));
		pay.setBorder(BorderFactory.createCompoundBorder());
		
		
		jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setBounds(5, 5, 25, 25);
		close.setBackground(Color.red);
		close.setContentAreaFilled(false);
		
		jf.setUndecorated(true);
		
		
		jf.setVisible(true);
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		
		close.addActionListener(this);
		pay.addActionListener(this);
		close.addMouseListener(this);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet","root","abhi");
			stmt=con.createStatement();
			}
			catch(Exception e) {}
		
	}
	
	public static void main(String[] args) 
	{
		new Pay();
	}


	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==close)
		{
			jf.setVisible(false);
		}
		if(ae.getSource()==pay)
		{
			int racc=Integer.parseInt(reciever.getText());
			int amt=Integer.parseInt(amount.getText());
			String n="";
			d=detail.getText();
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			
			try {
					
					ResultSet rs=stmt.executeQuery("select name from bank where acc_no='"+racc+"'");
					if(rs.next())
						n=rs.getString("name");
					
					java.sql.PreparedStatement ps0=con.prepareStatement("insert into transaction (user1_id,user2_id,amount,time,detail) values(?,?,?,?,?)");
					ps0.setInt(1, acc);;
					ps0.setInt(2, racc);
					ps0.setInt(3, amt);
					ps0.setString(4, timestamp.toString());
					ps0.setString(5, d);
					int i=ps0.executeUpdate();
					JOptionPane.showMessageDialog(jf,"sucessfully inserted!!: "+i+": Record");
					
				PreparedStatement ps1=con.prepareStatement("update bank set balance=balance-? where acc_no=?");
				ps1.setInt(1, amt);
				ps1.setInt(2, acc);
				int z=ps1.executeUpdate();
				
				PreparedStatement ps2=con.prepareStatement("update bank set balance=balance+? where acc_no=?");
				ps2.setInt(1,amt);
				ps2.setInt(2, racc);
				int y=ps2.executeUpdate();
				
				
				if(y>0 && z>0)
				{	con.commit();
					
					
					JOptionPane.showMessageDialog(jf,"sucessfully updated!!");
				}
				else
				{	con.rollback();
					JOptionPane.showMessageDialog(jf,"Unsucessful!!:");
				}
				
				
				
			} catch (Exception e) {}
		}
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getComponent()==close)
		{
		close.setContentAreaFilled(true);
		close.setBackground(Color.red);
		}
	}
	@Override
	public void mouseExited(MouseEvent e) {
		close.setContentAreaFilled(false);
	}
	@Override
	public void mousePressed(MouseEvent e) {
		
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}	