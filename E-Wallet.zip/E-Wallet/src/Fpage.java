import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Fpage implements ActionListener,MouseListener,FocusListener  
{
	JFrame jf;
	JPanel jp1,jp2,jp3,jp4,jp5;
	JButton close,signup,wallet,ace,he;
	JLabel jl2;
	
	
	
	Fpage()
	{
		jf=new JFrame();
		jf.setLayout(null);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg26.jpg")));
		
		jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setContentAreaFilled(false);
		close.setBounds(5, 5, 25, 25);

		jf.add(jl2=new JLabel("New User?"));
		jl2.setBorder(null);
		jl2.setOpaque(false);
		jl2.setBounds(1160, 10, 100, 40);
		jl2.setFont(new Font("Cooper",Font.BOLD,17));
		jl2.setForeground(Color.white);
		
		jf.add(signup=new JButton("Sign Up"));
		signup.setBorder(BorderFactory.createLineBorder(Color.white));
		signup.setContentAreaFilled(false);
		signup.setBounds(1256, 10, 100, 40);
		signup.setFont(new Font("Cooper",Font.PLAIN,20));
		signup.setForeground(Color.white);
		signup.addActionListener(this);
		
		jf.add(wallet=new JButton("Wallet"));
		wallet.setBounds(456,250,450 ,50);
		wallet.setFont(new Font("Cooper",Font.ROMAN_BASELINE,30));
		wallet.setBorder(BorderFactory.createRaisedBevelBorder());
		wallet.setBackground(Color.getHSBColor(27, 201, 128));
		wallet.setForeground(Color.white);
		wallet.addActionListener(this);
		
		
		jf.add(ace=new JButton("Academic Enquiry"));
		ace.setBounds(456,350,450 ,50);
		ace.setFont(new Font("Cooper",Font.ROMAN_BASELINE,30));
		ace.setBorder(BorderFactory.createRaisedBevelBorder());
		ace.setBackground(Color.getHSBColor(27, 201, 128));
		ace.setForeground(Color.white);
		ace.setContentAreaFilled(false);
		ace.addActionListener(this);
		
		jf.add(he=new JButton("Hostel Enquiry"));
		he.setBounds(456,450,450 ,50);
		he.setFont(new Font("Cooper",Font.ROMAN_BASELINE,30));
		he.setBorder(BorderFactory.createRaisedBevelBorder());
		he.setBackground(Color.getHSBColor(27, 201, 128));
		he.setForeground(Color.white);
		he.addActionListener(this);
		
		close.addMouseListener(this);		
		close.addActionListener(this);
		signup.addMouseListener(this);	
		signup.addActionListener(this);									
						
		
		jf.setUndecorated(true);
		jf.setExtendedState(jf.MAXIMIZED_BOTH);
		jf.setVisible(true);
		jf.setResizable(false);
		
	}
	
	public static void main(String[] args) 
	{
		new Fpage();
	}

	
	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==close)
		{
			System.exit(0);
		}
		if(ae.getSource()==signup)
		{
			new Option();
		}
		if(ae.getSource()==wallet)
		{
			new Login();
		}
		if(ae.getSource()==ace)
		{
			
		}
		if(ae.getSource()==he)
		{
			
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) 
	{
		
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) 
	{
		if(arg0.getComponent()==close)
		{
		close.setContentAreaFilled(true);
		close.setBackground(Color.red);
		}
		if(arg0.getComponent()==signup)
		{
		signup.setContentAreaFilled(true);
		signup.setBackground(new Color(78,27,133,255));
		}
	}

	@Override
	public void mouseExited(MouseEvent arg0) 
	{
		close.setContentAreaFilled(false);
		signup.setContentAreaFilled(false);
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void focusGained(FocusEvent e) 
	{
		
		
	}

	@Override
	public void focusLost(FocusEvent e) 
	{
				
	}
}
