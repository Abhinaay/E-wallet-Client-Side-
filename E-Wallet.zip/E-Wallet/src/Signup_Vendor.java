import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;

import java.awt.event.*;
import java.sql.*;

public class Signup_Vendor implements ActionListener,MouseListener
{
	JFrame jf;
	JPanel jp1;
	JButton close,register;
	JTextField balance,pin,stu_id,name,phone,email,type,address;
	JLabel bl,pinl,sl,nl,pl,el,tl,al;	
	Connection con;
	Statement stmt;
	String id;
	
	Signup_Vendor()
	{
		jf=new JFrame();
		jf.setLayout(null);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg37.jpg")));
		jf.setSize(500, 635);
		
		jf.add(jp1=new JPanel());
		jp1.setBounds(100,0,300 ,612);
		jp1.setLayout(null);
		jp1.setBackground(new Color(0,0,0,100));
		jp1.setBorder(BorderFactory.createTitledBorder("<html><body color='orange'><font size=6>SignUp</font></body></html>"));
									
		jp1.add(nl=new JLabel("Enter Your Name:"));
		nl.setBounds(10, 30, 280, 50);
		nl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		nl.setHorizontalTextPosition(SwingConstants.LEFT);
		nl.setForeground(Color.ORANGE);
		
		jp1.add(name=new JTextField());
		name.setBounds(10, 70, 280, 25);
		name.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		name.setBorder(null);
		
		jp1.add(pl=new JLabel("Enter Your Phone Number:"));
		pl.setBounds(10, 100, 280, 50);
		pl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		pl.setHorizontalTextPosition(SwingConstants.LEFT);
		pl.setForeground(Color.orange);
		
		jp1.add(phone=new JTextField());
		phone.setBounds(10, 140, 280, 25);
		phone.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		phone.setBorder(null);

		jp1.add(el=new JLabel("Enter Your Email:"));
		el.setBounds(10, 170, 280, 50);
		el.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		el.setHorizontalTextPosition(SwingConstants.LEFT);
		el.setForeground(Color.orange);
		
		jp1.add(email=new JTextField());
		email.setBounds(10, 210, 280, 25);
		email.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		email.setBorder(null);
		
		jp1.add(tl=new JLabel("What Do yo sell?"));
		tl.setBounds(10, 240, 280, 50);
		tl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		tl.setHorizontalTextPosition(SwingConstants.LEFT);
		tl.setForeground(Color.orange);
		
		jp1.add(type=new JTextField());
		type.setBounds(10, 280, 280, 25);
		type.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		type.setBorder(null);
		
		jp1.add(al=new JLabel("Enter Your Block:"));
		al.setBounds(10, 310, 280, 50);
		al.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		al.setHorizontalTextPosition(SwingConstants.LEFT);
		al.setForeground(Color.orange);
		
		jp1.add(address=new JTextField());
		address.setBounds(10, 350, 280, 25);
		address.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		address.setBorder(null);
		
		jp1.add(pinl=new JLabel("Enter Pin:"));
		pinl.setBounds(10, 380, 280, 50);
		pinl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		pinl.setHorizontalTextPosition(SwingConstants.LEFT);
		pinl.setForeground(Color.orange);
		
		jp1.add(pin=new JTextField());
		pin.setBounds(10, 420, 280, 25);
		pin.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		pin.setBorder(null);
		
		jp1.add(bl=new JLabel("Enter Balance:"));
		bl.setBounds(10, 450, 280, 50);
		bl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		bl.setHorizontalTextPosition(SwingConstants.LEFT);
		bl.setForeground(Color.orange);
		
		jp1.add(balance=new JTextField());
		balance.setBounds(10, 490, 280, 25);
		balance.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		balance.setBorder(null);
		
		jp1.add(register=new JButton("Register"));
		register.setBounds(50, 540, 200, 50);
		register.setFont(new Font("Cooper",Font.BOLD,40));
		register.setForeground(Color.white);
		register.setBackground(new Color(78,27,133,255));
		register.setBorder(BorderFactory.createCompoundBorder());
		
		jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setBounds(5, 5, 25, 25);
		close.setBackground(Color.red);
		close.setContentAreaFilled(false);
		
		jf.setUndecorated(true);
		jf.setVisible(true);
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		
		close.addActionListener(this);
		register.addActionListener(this);
		close.addMouseListener(this);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet","root","abhi");
			stmt=con.createStatement();
			}
			catch(Exception e) {}
		
	}
	
	public static void main(String[] args) 
	{
		new Signup_Vendor();
	}


	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==close)
		{
			jf.setVisible(false);
		}
		if(ae.getSource()==register)
		{
			
			try {
				java.sql.PreparedStatement ps2=con.prepareStatement("insert into bank (name,pin,balance) values(?,?,?)");
				ps2.setString(1, name.getText());
				ps2.setString(2, pin.getText());
				ps2.setString(3, balance.getText());
								
				int i=ps2.executeUpdate();
				//JOptionPane.showMessageDialog(jf,"sucessfully inserted!!: "+i+": Record");
				
				java.sql.PreparedStatement ps4=con.prepareStatement("select acc_no from bank where pin=?");
				ps4.setString(1, pin.getText());
				ResultSet rs=ps4.executeQuery();
				if(rs.next())
				{
					id=Integer.toString(rs.getInt("acc_no"));
				}
				
				java.sql.PreparedStatement ps1=con.prepareStatement("insert into login values (?,?,?)");
				ps1.setString(1, id);
				ps1.setString(2, name.getText());
				ps1.setString(3, pin.getText());
				
				int k=ps1.executeUpdate();
				
				java.sql.PreparedStatement ps3=con.prepareStatement("insert into vendor values (?,?,?,?,?,?)");
				ps3.setString(1, id);
				ps3.setString(2, name.getText());
				ps3.setString(3, type.getText());
				ps3.setString(4, phone.getText());
				ps3.setString(5, email.getText());
				ps3.setString(6, address.getText());
								
				int j=ps3.executeUpdate();
				JOptionPane.showMessageDialog(jf,"sucessfully inserted!!: "+j+": Record");
			
			
			
				
			} catch (SQLException e) {e.printStackTrace();}
		
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getComponent()==close)
		{
		close.setContentAreaFilled(true);
		close.setBackground(Color.red);
		}

		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		close.setContentAreaFilled(false);
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}	