import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Recharge implements ActionListener,MouseListener
{
	JFrame jf;
	JPanel jp1;
	JButton close,recharge;
	JTextField acc_no,amount;
	JLabel accl,al;	
	Connection con;
	Statement stmt;
	
	Recharge()
	{
		jf=new JFrame();
		jf.setLayout(null);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg37.jpg")));
		jf.setSize(500, 250);
		
		jf.add(jp1=new JPanel());
		jp1.setBounds(100,0,300 ,250);
		jp1.setLayout(null);
		jp1.setBackground(new Color(0,0,0,100));
									
		jp1.add(accl=new JLabel("Account Number:"));
		accl.setBounds(10, 10, 280, 50);
		accl.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		accl.setHorizontalTextPosition(SwingConstants.LEFT);
		accl.setForeground(Color.ORANGE);
		
		jp1.add(acc_no=new JTextField());
		acc_no.setBounds(10, 50, 280, 25);
		acc_no.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		acc_no.setBorder(null);
		
		jp1.add(al=new JLabel("Amount:"));
		al.setBounds(10, 80, 280, 50);
		al.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		al.setHorizontalTextPosition(SwingConstants.LEFT);
		al.setForeground(Color.orange);
		
		jp1.add(amount=new JTextField());
		amount.setBounds(10, 120, 280, 25);
		amount.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		amount.setBorder(null);

		jp1.add(recharge=new JButton("Recharge"));
		recharge.setBounds(50, 170, 200, 50);
		recharge.setFont(new Font("Cooper",Font.BOLD,40));
		recharge.setForeground(Color.white);
		recharge.setBackground(new Color(78,27,133,255));
		recharge.setBorder(BorderFactory.createCompoundBorder());
		
		jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setBounds(5, 5, 25, 25);
		close.setBackground(Color.red);
		close.setContentAreaFilled(false);
		
		jf.setUndecorated(true);
		jf.setVisible(true);
		jf.setResizable(false);
		jf.setLocationRelativeTo(null);
		
		close.addActionListener(this);
		recharge.addActionListener(this);
		close.addMouseListener(this);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet","root","abhi");
			stmt=con.createStatement();
			}
			catch(Exception e) {}
		
	}
	
	public static void main(String[] args) 
	{
		new Recharge();
	}


	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==close)
		{
			jf.setVisible(false);
		}
		if(ae.getSource()==recharge)
		{
			int ac=Integer.parseInt(acc_no.getText());
			int amt=Integer.parseInt(amount.getText());
			int famt=0;
			try {
				ResultSet rs=stmt.executeQuery("select balance from bank where acc_no='"+ac+"'");
				if(rs.next())
					famt+=rs.getInt("balance");
				famt+=amt;
				int i=stmt.executeUpdate("update bank set balance='"+famt+"'  where acc_no='"+ac+"' ");
				
				//JOptionPane.showMessageDialog(jf,"sucessfully updated!!: "+i+": Record");
			} catch (Exception e) {}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getComponent()==close)
		{
		close.setContentAreaFilled(true);
		close.setBackground(Color.red);
		}

		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		close.setContentAreaFilled(false);
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}	