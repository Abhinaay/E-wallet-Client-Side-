import java.awt.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;

import com.mysql.jdbc.Statement;

import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.sql.ResultSet;

public class Wallet_Home implements ActionListener,MouseListener
{
	JFrame jf;
	JPanel jp1,jp2;
	JButton close,line,recharge,pay,refresh,help,passbook;
	JLabel head,amt,amtbox,picon,userbox,uname;
	JTable jt1;
	JScrollPane sp;
	String column[]= {"<html><body><B>Transaction_ID</B></body></html>","<html><body><B>Paid_To</B></body></html>","<html><body><B>Amount(Rs.)</B></body></html>","<html><body><B>Time</B></body></html>","<html><body><B>Details</B></body></html>"};
	DefaultTableModel tm=new DefaultTableModel(column, 100);
	
	static String user;
	String tname,time;
	String[] arr=new String[5];
	int tu2id;
	int row=0;
	String td;
	static //JTextField ;
	int user_id;
	static int balance;
	int tid;
	int tamt;
	Connection con;
	java.sql.Statement stmt;
	Timestamp t;
	String[][] alist= new String[100][];
	ArrayList<String[]> list=new ArrayList<>();
	
	
	
	Wallet_Home(int i,int balance,String user)
	{
		this();
		user_id=i;
		this.user=user;
		this.balance=balance;
		amtbox.setText(Integer.toString(balance));
		userbox.setText(user);
	}
	Wallet_Home()
	{

		
		jf=new JFrame();
		jf.setLayout(null);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg26.jpg")));
		
		jf.add(jp1=new JPanel());
		jp1.setBounds(256,0,850 ,770);
		jp1.setBackground(new Color(0,0,0,100));
		jp1.setLayout(null);
		
		jp1.add(head=new JLabel("MANIPAL UNIVERSITY JAIPUR"));
		head.setBounds(0, 0, 850, 70);
		head.setForeground(Color.WHITE);
		head.setHorizontalAlignment(SwingConstants.CENTER);
		head.setFont(new Font("Cooper",Font.BOLD,50));
		head.setBackground(Color.getHSBColor(20, 240, 120));
		head.setBorder(BorderFactory.createDashedBorder(Color.getHSBColor(20, 240, 120), 5, 10, 5, true));
			
		jp1.add(amt=new JLabel("Amount: Rs."));
		amt.setBounds(10, 110, 100, 25);
		amt.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		amt.setForeground(Color.WHITE);
		//amt.setBorder(BorderFactory.createDashedBorder(Color.getHSBColor(20, 240, 120), 5, 10, 5, true));
		amt.setOpaque(false);
		amt.setHorizontalAlignment(SwingConstants.LEFT);
		
		jp1.add(amtbox=new JLabel());
		amtbox.setBounds(110, 110, 80, 25);
		amtbox.setForeground(Color.WHITE);
		amtbox.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		//amtbox.setBorder(BorderFactory.createDashedBorder(Color.getHSBColor(20, 240, 120), 5, 10, 5, true));
		amtbox.setBorder(null);
		amtbox.setOpaque(false);
		
		
		jp1.add(picon=new JLabel(new ImageIcon("img\\uidicon.png")));
		picon.setBounds(815, 110, 25, 25);
		
		jp1.add(userbox=new JLabel());
		userbox.setBounds(730, 110, 75, 25);
		userbox.setForeground(Color.WHITE);
		userbox.setHorizontalAlignment(SwingConstants.RIGHT);
		userbox.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		
		//userbox.setBorder(BorderFactory.createDashedBorder(Color.getHSBColor(20, 240, 120), 5, 10, 5, true));
		
		jp1.add(uname=new JLabel("Hello,"));
		uname.setBounds(675, 110, 60, 25);
		uname.setForeground(Color.WHITE);
		uname.setHorizontalAlignment(SwingConstants.RIGHT);
		uname.setFont(new Font("Comic Sans MS",Font.BOLD,17));
		//uname.setBorder(BorderFactory.createDashedBorder(Color.getHSBColor(20, 240, 120), 5, 10, 5, true));
		
		jp1.add(line=new JButton());
		line.setBounds(0, 150, 850, 10);
		line.setForeground(Color.WHITE);
		line.setBackground(Color.darkGray);
		line.setBorder(null);
		
		jt1=new JTable(100, 5);
		jt1.setModel(tm);
		
		
		sp=new JScrollPane(jt1);
		sp.setBounds(10, 300, 830, 450);
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		jp1.add(sp);
		
		jp1.add(recharge=new JButton("Recharge"));
		recharge.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		recharge.setBounds(10, 170, 410, 50);
		recharge.setBackground(new Color(78,27,133,255));
		recharge.setForeground(Color.white);
		recharge.setBorder(null);
		
		
		jp1.add(pay=new JButton("PAY"));
		pay.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		pay.setBounds(430, 170, 410, 50);
		pay.setBackground(new Color(78,27,133,255));
		pay.setForeground(Color.white);
		pay.setBorder(null);
		
		
		jp1.add(passbook=new JButton("PassBook"));
		passbook.setFont(new Font("Comic Sans MS",Font.BOLD,30));
		passbook.setBounds(213, 240, 410, 50);
		passbook.setBorder(BorderFactory.createDashedBorder(new Color(78,27,133,255), 4, 10, 2, true));
		passbook.setForeground(Color.WHITE);
		passbook.setHorizontalAlignment(SwingConstants.CENTER);
		passbook.setBackground(new Color(78,27,133,255));
		
		jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setBounds(5, 5, 25, 25);
		close.setBackground(Color.red);
		close.setContentAreaFilled(false);
		
		jf.add(refresh=new JButton("<html><font size=6>R</font></html>"));
		refresh.setBorder(null);
		refresh.setBounds(35, 5, 25, 25);
		refresh.setBackground(Color.pink);
		refresh.setContentAreaFilled(false);
	
		jf.add(help=new JButton("<html><font size=6>H</font></html>"));
		help.setBorder(null);
		help.setBounds(65, 5, 25, 25);
		help.setBackground(Color.BLUE);
		help.setContentAreaFilled(false);
		
		jf.setUndecorated(true);
		jf.setExtendedState(jf.MAXIMIZED_BOTH);
		jf.setVisible(true);
		jf.setResizable(false);
		
		close.addMouseListener(this);
		close.addActionListener(this);
		pay.addActionListener(this);
		recharge.addActionListener(this);
		refresh.addActionListener(this);
		refresh.addMouseListener(this);
		help.addActionListener(this);
		help.addMouseListener(this);
		passbook.addActionListener(this);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet","root","abhi");
			stmt=con.createStatement();
			
			
			}
			catch(Exception ex)
			{}
			
		
	
	}
		
	
	
	public static void main(String[] args) 
	{
		new Wallet_Home();
	}


	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==close)
		{
			jf.setVisible(false);
		}
		if(ae.getSource()==pay)
		{
			new Pay(user_id);
		}
		if(ae.getSource()==recharge)
		{
			new Recharge();
		}
		if(ae.getSource()==refresh)
		{	jf.dispose();
		
		
			try {
				ResultSet rs=stmt.executeQuery("select balance from bank where acc_no='"+user_id+"'");
				if(rs.next())
						balance=rs.getInt("balance");	
				new Wallet_Home(user_id,balance,user);
			} catch (SQLException e) {}
			
		}
		if(ae.getSource()==help)
		{
			new Help();
		}
		if(ae.getSource()==passbook)
		{
			
			try {
				ResultSet rs2=stmt.executeQuery("select * from transaction where user1_id='"+user_id+"'");
				
				while(rs2.next())
				{int j=0;
					arr[j]=Integer.toString(rs2.getInt("t_id"));
					Object ob=arr[j];
					jt1.setValueAt(ob, row, 0);
					j++;
					arr[j]=Integer.toString(rs2.getInt("user2_id"));
					Object ob1=arr[j];
					jt1.setValueAt(ob1,row, 1);
					j++;
					arr[j]=Integer.toString(rs2.getInt("amount"));
					Object ob2=arr[j];
					jt1.setValueAt(ob2,row, 2);
					j++;
					arr[j]=rs2.getString("time");
					Object ob3=arr[j];
					jt1.setValueAt(ob3, row, 3);
					j++;
					arr[j]=rs2.getString("detail");
					Object ob4=arr[j];
					jt1.setValueAt(ob4, row, 4);
					
					row++;
					
				}
					
				
				
			} catch (Exception e) {}
		}
	}
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getComponent()==close)
		{
			close.setContentAreaFilled(true);
			close.setBackground(Color.red);
		}
		if(e.getComponent()==refresh)
		{
			refresh.setContentAreaFilled(true);
			refresh.setBackground(Color.pink);
		}
		if(e.getComponent()==help)
		{
			help.setContentAreaFilled(true);
			help.setBackground(Color.blue);
		}
	}
	@Override
	public void mouseExited(MouseEvent e) {
		close.setContentAreaFilled(false);
		refresh.setContentAreaFilled(false);
		help.setContentAreaFilled(false);
	}
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}	