import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class Help implements ActionListener,MouseListener
{
	JFrame jf;
	
	JButton close;
	JTextArea jta;
	Connection con;
	Statement stmt;
	JScrollPane sp;
	
	Help()
	{
		jf=new JFrame();
		jf.setLayout(null);
		jf.setContentPane(new JLabel(new ImageIcon("img\\bg37.jpg")));
		jf.setSize(200, 250);
		
		jta=new JTextArea();
		jta.setText("     Acc_no"+" : "+"Name");
		jf.add(sp=new JScrollPane(jta));
		sp.setBounds(20, 20, 160, 205);
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
									
				jf.add(close=new JButton("<html><font size=6>x</font></html>"));
		close.setBorder(null);
		close.setBounds(5, 5, 25, 25);
		close.setBackground(Color.red);
		close.setContentAreaFilled(false);
		
		jf.setUndecorated(true);
		jf.setVisible(true);
		jf.setResizable(false);
		
		
		close.addActionListener(this);
		
		close.addMouseListener(this);
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/wallet","root","abhi");
			stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select * from bank");
			while(rs.next())
			{
				jta.append("\n         "+rs.getString("acc_no")+"     : "+rs.getString("name"));
			}
			
			}
			catch(Exception e) {}
		
	}
	
	public static void main(String[] args) 
	{
		new Help();
	}


	public void actionPerformed(ActionEvent ae) 
	{
		if(ae.getSource()==close)
		{
			jf.setVisible(false);
		}
		
		}
	

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		if(e.getComponent()==close)
		{
		close.setContentAreaFilled(true);
		close.setBackground(Color.red);
		}

		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		close.setContentAreaFilled(false);
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	
}	